

%% Banking angle

t_sig = [0 510 510 700 700 1500];
y_sig = [0 0 360 360 0 0];